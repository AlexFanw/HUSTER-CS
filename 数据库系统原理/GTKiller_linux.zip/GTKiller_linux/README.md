# GTKiller app

运行环境：`JDK13` + linux/macOS

```shell
#使用如下命令打开项目
./launch.sh				//linux
# windows自行仿照launch.sh的命令编写吧
```

